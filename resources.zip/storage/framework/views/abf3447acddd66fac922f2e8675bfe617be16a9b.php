<?php if(\Auth::check() && \Auth::user()->canManageBinshopsBlogPosts()): ?>
    <a href="<?php echo e($post->edit_url()); ?>" class="btn btn-outline-secondary btn-sm pull-right float-right">Edit
        Post</a>
<?php endif; ?>

<h1 class='blog_title'><?php echo e($post->title); ?></h1>
<h5 class='blog_subtitle'><?php echo e($post->subtitle); ?></h5>


<?=$post->image_tag("medium", false, 'd-block mx-auto'); ?>

<p class="blog_body_content">
    <?php echo $post->post_body_output(); ?>


    
    
    
    
    
    
    
</p>

<hr/>

Posted <strong><?php echo e($post->post->posted_at->diffForHumans()); ?></strong>

<?php echo $__env->renderWhen($post->author,"binshopsblog::partials.author",['post'=>$post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
<?php echo $__env->renderWhen($categories,"binshopsblog::partials.categories",['categories'=>$categories], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path'])); ?>
<?php /**PATH C:\Users\TEST\Documents\web-projects\fixedfloat\resources\views/vendor/binshopsblog/partials/full_post_details.blade.php ENDPATH**/ ?>