<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH C:\Users\TEST\Documents\web-projects\fixedfloat\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>