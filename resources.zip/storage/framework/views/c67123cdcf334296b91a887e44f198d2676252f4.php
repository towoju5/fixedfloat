<?php $__env->startSection('blog-custom-css'); ?>
    <link type="text/css" href="<?php echo e(asset('binshops-blog.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>

    <?php if(config("binshopsblog.reading_progress_bar")): ?>
        <div id="scrollbar">
            <div id="scrollbar-bg"></div>
        </div>
    <?php endif; ?>

    

    <div class='container'>
    <div class='row'>
        <div class='col-sm-12 col-md-12 col-lg-12'>

            <?php echo $__env->make("binshopsblog::partials.show_errors", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo $__env->make("binshopsblog::partials.full_post_details", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


            <?php if(config("binshopsblog.comments.type_of_comments_to_show","built_in") !== 'disabled'): ?>
                <div class="" id='maincommentscontainer'>
                    <h2 class='text-center' id='binshopsblogcomments'>Comments</h2>
                    <?php echo $__env->make("binshopsblog::partials.show_comments", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
            <?php else: ?>
                
            <?php endif; ?>


        </div>
    </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('blog-custom-js'); ?>
    <script src="<?php echo e(asset('binshops-blog.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.app",['title'=>$post->gen_seo_title()], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TEST\Documents\web-projects\fixedfloat\resources\views/vendor/binshopsblog/single_post.blade.php ENDPATH**/ ?>