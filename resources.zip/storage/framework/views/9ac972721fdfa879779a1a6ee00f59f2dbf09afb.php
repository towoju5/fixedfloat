<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="wrapper clrfix">
    <section class="content narrow">
        <h1><?php echo e(ucwords(strtolower($data['title']))); ?></h1>
        <section class="content-box">
            <br>
            <?php echo $data['body']; ?>

        </section>
    </section>
</div>

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TEST\Documents\web-projects\fixedfloat\resources\views/about.blade.php ENDPATH**/ ?>