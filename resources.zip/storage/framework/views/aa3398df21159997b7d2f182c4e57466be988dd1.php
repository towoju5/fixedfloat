

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php $user = auth()->user() ?>
<div class="container-xxl flex-grow-1 container-p-y">
   <div class="row">
      <!-- Order Statistics -->
      <div class="col-md-12 order-0 mb-4">
         <div class="card">
            <div class="card-body">
               <h5 class="card-header"><?php echo e(__('Payout')); ?></h5>
               <form action="" method="post">
                  <div class="form-group row">
                     <label class="col-md-2 col-form-label" for=""><?php echo e(__('Bitcoin address')); ?>:</label>
                     <div class="col-md-8">
                        <input type="text" class="form-control" name="wallet_address" id="wallet_address">
                     </div>
                  </div>
                  <div class="form-group row">
                     <label class="col-md-2 col-form-label" for=""><?php echo e(__('Ready to payout')); ?>:</label>
                     <div class="col-md-8">
                        <p class="form-control-plaintext" readonly id="payout_amount">0 BTC (0 BTC less than the minimum 0.001 BTC</p>
                     </div>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <!--/ Order Statistics -->
   </div>

   <div class="row">
      <!-- Order Statistics -->
      <div class="col-md-12 order-0 mb-4">
         <div class="card">
            <h5 class="card-header"><?php echo e(__('Last payouts')); ?></h5>
            <div class="table-responsive text-nowrap">
               <table class="table">
                  <caption class="ms-4"><?php echo e($payouts->render('pagination')); ?></caption>
                  <thead>
                     <tr>
                        <th>S/N</th>
                        <th>Amount</th>
                        <th>Status</th>
                        <th>Date</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                     <tr>
                        <td><?php echo e($k+1); ?></td>
                        <td><?php echo e($list->amount); ?></td>
                        <td><?php echo e($list->status); ?></td>
                        <td><?php echo e(show_datetime($list->created_at)); ?></td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                     <tr>
                        <td colspan="4" class="h3 text-center">
                           <?php echo e(__('No Transaction Found')); ?>

                        </td>
                     </tr>
                     <?php endif; ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
      <!--/ Order Statistics -->
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\fixedfloat\resources\views/users/trans/payout.blade.php ENDPATH**/ ?>