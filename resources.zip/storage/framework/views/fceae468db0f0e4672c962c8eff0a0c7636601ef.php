

<?php $__env->startPush('css'); ?>
<style>
   .bg-soft-primary {
      background-color: rgba(85, 110, 230, .25) !important;
   }

   .mini-stats-wid .mini-stat-icon {
      overflow: hidden;
      position: relative;
   }

   .avatar-sm {
      height: 3rem;
      width: 3rem;
   }

   .align-self-center {
      -ms-flex-item-align: center !important;
      align-self: center !important;
   }

   .rounded-circle {
      border-radius: 50% !important;
   }

   .avatar-title {
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
      background-color: #556ee6;
      color: #fff;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      font-weight: 500;
      height: 100%;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      justify-content: center;
      width: 100%;
   }

   .text-truncate {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
   }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php $user = auth()->user() ?>
<div class="container-xxl flex-grow-1 container-p-y">
   <div class="row">
      <div class="col-xl-5">
         <div class="card">
            <div class="card-body">
               <h4 class="card-title mb-4"><?php echo e(__('Personal Information')); ?></h4>
               <p class="text-muted mb-4"><?php echo e(__('Investor')); ?></p>
               <div class="table-responsive">
                  <table class="table table-nowrap mb-0">
                     <tbody>
                        <tr>
                           <th scope="row"><?php echo e(__('Full Name')); ?>:</th>
                           <td><?php echo e($user->name); ?></td>
                        </tr>
                        <tr>
                           <th scope="row"><?php echo e(__('Mobile')); ?>:</th>
                           <td><?php echo e($user->phone ?? 'NULL'); ?></td>
                        </tr>
                        <tr>
                           <th scope="row"><?php echo e(__('E-mail')); ?>:</th>
                           <td><?php echo e($user->email); ?></td>
                        </tr>
                        <tr>
                           <th scope="row"><?php echo e(__('Location')); ?>:</th>
                           <td><?php echo e($user->location ?? 'NULL'); ?></td>
                        </tr>
                        <tr>
                           <th scope="row"><?php echo e(__('Country')); ?>:</th>
                           <td><?php echo e($user->country ?? 'NULL'); ?></td>
                        </tr>
                     </tbody>
                  </table>
               </div>
            </div>
         </div>
         <!-- end card -->
      </div>

      <div class="col-xl-7">
         <div class="card">
            <?php echo $__env->make('notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <form action="<?php echo e(route('users.profile.save', $user->id)); ?>" method="POST">
               <?php echo csrf_field(); ?>
               <div class="card-body">
                  <h4 class="card-title mb-4"><?php echo e(__('Change Password')); ?></h4>
                  <div class="form-group row">
                     <label class="col-md-3 col-form-label" for=""><?php echo e(__('New Password')); ?>:</label>
                     <div class="col-md-9">
                        <input type="password" class="form-control" name="password" id="pa">
                     </div>
                  </div>
                  <div class="form-group row">
                     <label class="col-md-3 col-form-label" for=""><?php echo e(__('Confirm Password')); ?>:</label>
                     <div class="col-md-9">
                        <input type="password" class="form-control" name="password_confirmation" id="pac">
                     </div>
                  </div>
                  <div class="alert alert-danger" style="display:none" id="pacEr">
                     <span><?php echo e(__('Passwords do not match')); ?></span>
                  </div>
                  <hr>
                  <button type="submit" class="btn btn-primary btn-bloc waves-effect waves-light text-center">
                     <i class="fa fa-check"></i> <?php echo e(__('Change Password')); ?>

                  </button>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TEST\Documents\web-projects\fixedfloat\resources\views/users/profile/index.blade.php ENDPATH**/ ?>