

<?php $__env->startPush('css'); ?>
<style>
   .bg-soft-primary {
      background-color: rgba(85, 110, 230, .25) !important;
   }

   .mini-stats-wid .mini-stat-icon {
      overflow: hidden;
      position: relative;
   }

   .avatar-sm {
      height: 3rem;
      width: 3rem;
   }

   .align-self-center {
      -ms-flex-item-align: center !important;
      align-self: center !important;
   }

   .rounded-circle {
      border-radius: 50% !important;
   }

   .avatar-title {
      -webkit-box-align: center;
      -ms-flex-align: center;
      align-items: center;
      background-color: #556ee6;
      color: #fff;
      display: -webkit-box;
      display: -ms-flexbox;
      display: flex;
      font-weight: 500;
      height: 100%;
      -webkit-box-pack: center;
      -ms-flex-pack: center;
      justify-content: center;
      width: 100%;
   }

   .text-truncate {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
   }
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php $user = auth()->user() ?>
<div class="container-xxl flex-grow-1 container-p-y">
   <div class="row">
      <!-- Order Statistics -->
      <div class="col-md-12 order-0 mb-4">
         <div class="card">
            <h5 class="card-header"><?php echo e(__('Active orders')); ?></h5>
            <div class="table-responsive text-nowrap">
               <table class="table">
                  <caption class="ms-4"><?php echo e($lists->render('pagination')); ?></caption>
                  <thead>
                     <tr>
                        <th>S/N</th>
                        <th>Time</th>
                        <th>Send</th>
                        <th>Receive</th>
                        <th>Status</th>
                        <th>Date</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $actives; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $active): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                     <tr>
                        <td><?php echo e($k+1); ?></td>
                        <td><?php echo e($active->time); ?></td>
                        <td><?php echo e($active->send); ?></td>
                        <td><?php echo e($active->receive); ?></td>
                        <td><?php echo e($active->status); ?></td>
                        <td><?php echo e(show_datetime($lists->created_at)); ?></td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                     <tr>
                        <td colspan="6" class="h3 text-center">
                           <?php echo e(__('No Transaction Found')); ?>

                        </td>
                     </tr>
                     <?php endif; ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
      <!--/ Order Statistics -->
   </div>

   <div class="row">
      <!-- Order Statistics -->
      <div class="col-md-12 order-0 mb-4">
         <div class="card">
            <h5 class="card-header"><?php echo e(__('Сompleted orders')); ?></h5>
            <div class="table-responsive text-nowrap">
               <table class="table">
                  <caption class="ms-4"><?php echo e($lists->render('pagination')); ?></caption>
                  <thead>
                     <tr>
                        <th>S/N</th>
                        <th>Order ID</th>
                        <th>Send</th>
                        <th>Received</th>
                        <th>Received Address</th>
                        <th>Date</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                     <tr>
                        <td><?php echo e($k+1); ?></td>
                        <td><?php echo e($list->order_id); ?></td>
                        <td><?php echo e($list->send); ?></td>
                        <td><?php echo e($list->received); ?></td>
                        <td><?php echo e($list->received_address); ?></td>
                        <td><?php echo e(show_datetime($list->created_at)); ?></td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                     <tr>
                        <td colspan="6" class="h3 text-center">
                           <?php echo e(__('No Transaction Found')); ?>

                        </td>
                     </tr>
                     <?php endif; ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
      <!--/ Order Statistics -->
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projects\fixedfloat\resources\views/users/trans/index.blade.php ENDPATH**/ ?>