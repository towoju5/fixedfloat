

<?php $__env->startPush('css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<?php $user = auth()->user() ?>
<div class="container-xxl flex-grow-1 container-p-y">
   <div class="row">
      <!-- Order Statistics -->
      <div class="col-md-12 order-0 mb-4">
         <div class="card">
            <div class="card-body">
               <h5 class="card-header"><?php echo e(__('Payout')); ?></h5>
               <?php echo $__env->make('notification', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               <form action="<?php echo e(route('users.trans.payouts.request')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <div class="form-group row">
                     <label class="col-md-2 col-form-label" for="wallet_address"><?php echo e(__('Bitcoin address')); ?>:</label>
                     <div class="col-md-8">
                        <input type="text" class="form-control" name="wallet_address" id="wallet_address">
                     </div>
                  </div>
                  <div class="form-group row" hidden>
                     <label class="col-md-2 col-form-label" for="amount"><?php echo e(__('Amount')); ?>:</label>
                     <div class="col-md-8">
                        <input type="hidden" class="form-control" name="amount" value="<?php echo e($user->btc_balance); ?>" id="amount">
                     </div>
                  </div>
                  <div class="form-group row">
                     <label class="col-md-2 col-form-label" for=""><?php echo e(__('Ready to payout')); ?>:</label>
                     <div class="col-md-8">
                        <p class="form-control-plaintext" readonly id="payout_amount"><?php echo e(number_format($user->btc_balance, 4)); ?> BTC 
                           <?php if($user->btc_balance < 0.001): ?> (<?php echo e(number_format($user->btc_balance, 3)); ?>  BTC <?php echo e(__('less than the minimum')); ?> <b>0.001 BTC</b> <?php endif; ?></p>
                     </div>
                  </div>
                  <div class="d-flex justify-content-center">
                     <button type="submit" class="btn btn-info btn-rounded"><?php echo e(__('Payout')); ?></button>
                  </div>
               </form>
            </div>
         </div>
      </div>
      <!--/ Order Statistics -->
   </div>

   <div class="row">
      <!-- Order Statistics -->
      <div class="col-md-12 order-0 mb-4">
         <div class="card">
            <h5 class="card-header"><?php echo e(__('Last payouts')); ?></h5>
            <div class="table-responsive text-nowrap">
               <table class="table">
                  <caption class="ms-4"><?php echo e($payouts->render('pagination')); ?></caption>
                  <thead>
                     <tr>
                        <th><?php echo e(__('S/N')); ?></th>
                        <th><?php echo e(__('Amount')); ?></th>
                        <th><?php echo e(__('Status')); ?></th>
                        <th><?php echo e(__('Date')); ?></th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php $__empty_1 = true; $__currentLoopData = $payouts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                     <tr>
                        <td><?php echo e($k+1); ?></td>
                        <td><?php echo e($list->amount); ?></td>
                        <td><?php echo e(status_code($list->status)); ?></td>
                        <td><?php echo e(show_datetime($list->created_at)); ?></td>
                     </tr>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                     <tr>
                        <td colspan="4" class="h3 text-center">
                           <?php echo e(__('No Transaction Found')); ?>

                        </td>
                     </tr>
                     <?php endif; ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
      <!--/ Order Statistics -->
   </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TEST\Documents\web-projects\fixedfloat\resources\views/users/trans/payout.blade.php ENDPATH**/ ?>