<?php 

return [
    'en' => 'English',
    'fr' => 'Français',
];